import 'package:dict/service/dictclient.dart';
import 'package:flutter/material.dart';

class homepage extends StatefulWidget {
  const homepage({super.key});

  @override
  State<homepage> createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  DictClient dClient = DictClient();
  TextEditingController tc = TextEditingController();
  String meaning = "null";
  callAPI(q) async {
    meaning = await dClient.searchForWord(query: q);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: AppBar(
              title: Text("Dictonary"),
            ),
            body: SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextField(
                        controller: tc,
                        decoration: InputDecoration(
                            border: const OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            suffixIcon: IconButton(
                                onPressed: () {},
                                icon: const Icon(Icons.clear)),
                            label: const Text("WORD"),
                            hintText: "Enter a Word Here"),
                      ),
                    ),
                    OutlinedButton(
                        onPressed: () {
                          callAPI(tc.text);
                          tc.clear();
                          setState(() {});
                        },
                        child: Text("Search")),
                    Container(
                        child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(meaning),
                    ))
                  ],
                ))));
  }
}
